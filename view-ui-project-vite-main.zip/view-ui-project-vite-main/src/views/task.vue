<template>
  task
</template>

<script>
import Demo from '@/components/Demo'
import Menu from '@/components/menu'

export default {
  name: 'Home',
  components: {
    Demo,
    Menu
  },
  setup() {
  },
  methods: {
  }
}
</script>

<style lang="less" scoped>
</style>
