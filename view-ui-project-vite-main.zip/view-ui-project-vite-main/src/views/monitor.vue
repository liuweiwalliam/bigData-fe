<template>
  monitor
</template>

<script>
import Demo from '@/components/Demo'

export default {
  name: 'Home',
  components: {
    Demo,
  },
  setup() {
  },
  methods: {
  }
}
</script>

<style lang="less" scoped>
</style>
